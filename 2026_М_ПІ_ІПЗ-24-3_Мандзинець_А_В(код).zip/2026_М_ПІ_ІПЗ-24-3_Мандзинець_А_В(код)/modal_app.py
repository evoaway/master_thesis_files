from __future__ import annotations

import json
import pickle
import re
from pathlib import Path
from typing import Any

import modal


app = modal.App("plag-detector")

image = (
    modal.Image.debian_slim(python_version="3.11")
    .pip_install(
        "sentence-transformers>=5.0,<6.0",
        "faiss-cpu==1.9.0",
        "numpy<2",
        "fastapi[standard]",
        "pydantic>=2.0",
    )
)

corpus_volume = modal.Volume.from_name("plag-corpus", create_if_missing=True)
models_volume = modal.Volume.from_name("plag-models", create_if_missing=True)

VOL = "/data"
MODELS = "/models"


UKR_ABBR = frozenset({
    "проф", "доц", "акад", "канд", "д-р", "ст",
    "ім", "вул", "просп", "пл", "буд", "кв", "обл", "р-н", "м", "с", "смт",
    "стор", "табл", "рис", "розд", "гл", "арк", "ч", "ред", "пер",
    "тис", "млн", "млрд", "грн", "коп",
    "т.д", "т.п", "т.зв", "напр", "зокр", "тощо",
    "укр", "англ", "лат", "грец", "рос",
})


def split_sentences(text: str, min_chars: int = 15) -> list[str]:

    if not text or not text.strip():
        return []
    text = re.sub(r"\s+", " ", text.replace("\n", " ")).strip()

    PH = "\u0001"

    def protect_abbr(m: re.Match) -> str:
        word = m.group(1).lower()
        return m.group(1) + PH if word in UKR_ABBR else m.group(0)

    text = re.sub(r"\b([А-Яа-яІіЇїЄєҐґA-Za-z\-]+)\.", protect_abbr, text)
    text = re.sub(
        r"\b([А-ЯІЇЄҐA-Z])\.\s*([А-ЯІЇЄҐA-Z])\.",
        rf"\1{PH} \2{PH}",
        text,
    )
    text = re.sub(r"\b([А-ЯІЇЄҐA-Z])\.\s+", rf"\1{PH} ", text)
    text = re.sub(r"(\d)\.(\d)", rf"\1{PH}\2", text)

    sents = re.split(r"(?<=[.!?…])\s+", text)
    sents = [s.replace(PH, ".").strip() for s in sents]
    return [s for s in sents if len(s) >= min_chars]


@app.function(
    image=image,
    gpu="T4",
    volumes={VOL: corpus_volume, MODELS: models_volume},
    timeout=3600,
)
def build_index(
    corpus_subdir: str = "raw_texts",
    biencoder_subdir: str = "biencoder_ft",
    batch_size: int = 64,
    use_hnsw: bool = False,
) -> dict[str, int]:

    import numpy as np
    import faiss
    from sentence_transformers import SentenceTransformer

    corpus_dir = Path(VOL) / corpus_subdir
    model_dir = Path(MODELS) / biencoder_subdir

    print(f"Завантаження bi-encoder з {model_dir}...")
    model = SentenceTransformer(str(model_dir), device="cuda")

    print(f"Зчитування {corpus_dir}...")
    sentences: list[str] = []
    sentence_meta: list[dict] = []
    sources: dict[str, dict] = {}

    files = sorted(corpus_dir.glob("*.txt"))
    if not files:
        raise RuntimeError(f"Не знайдено .txt файлів у {corpus_dir}")

    for fp in files:
        source_id = fp.stem
        sources[source_id] = {
            "id": source_id,
            "title": fp.name,
            "path": str(fp.relative_to(VOL)),
        }
        text = fp.read_text(encoding="utf-8", errors="replace")
        for pos, sent in enumerate(split_sentences(text)):
            sentences.append(sent)
            sentence_meta.append({"source_id": source_id, "position": pos})

    print(f"Всього речень: {len(sentences)} з {len(files)} документів")

    if not sentences:
        raise RuntimeError("Корпус порожній після розбиття на речення")

    print("Векторизація...")
    embs = model.encode(
        sentences,
        batch_size=batch_size,
        show_progress_bar=True,
        convert_to_numpy=True,
        normalize_embeddings=True,
    ).astype("float32")

    print(f"FAISS-індекс: {'HNSW' if use_hnsw else 'FlatIP'}, dim={embs.shape[1]}")
    dim = int(embs.shape[1])
    if use_hnsw:
        index = faiss.IndexHNSWFlat(dim, 32, faiss.METRIC_INNER_PRODUCT)
        index.hnsw.efConstruction = 200
        index.hnsw.efSearch = 64
    else:
        index = faiss.IndexFlatIP(dim)
    index.add(embs)

    print("Збереження артефактів...")
    out = Path(VOL)
    faiss.write_index(index, str(out / "faiss.index"))
    with open(out / "sentences.pkl", "wb") as f:
        pickle.dump({"sentences": sentences, "meta": sentence_meta}, f)
    with open(out / "sources.json", "w", encoding="utf-8") as f:
        json.dump(sources, f, ensure_ascii=False, indent=2)
    with open(out / "meta.json", "w", encoding="utf-8") as f:
        json.dump(
            {
                "n_sentences": len(sentences),
                "n_sources": len(sources),
                "dim": dim,
                "index_type": "HNSW" if use_hnsw else "FlatIP",
                "biencoder": biencoder_subdir,
                "normalized": True,
            },
            f,
            ensure_ascii=False,
            indent=2,
        )

    corpus_volume.commit()
    print("Індекс готовий і записаний у Volume.")
    return {"sentences": len(sentences), "sources": len(sources)}

@app.cls(
    image=image,
    gpu="T4",
    volumes={VOL: corpus_volume, MODELS: models_volume},
    scaledown_window=300,
    timeout=600,
    min_containers=0,
)
class PlagDetector:

    @modal.enter()
    def load(self) -> None:
        import faiss
        from sentence_transformers import SentenceTransformer, CrossEncoder

        print("Завантаження артефактів індексу...")
        with open(f"{VOL}/sentences.pkl", "rb") as f:
            data = pickle.load(f)
        self.db_sentences: list[str] = data["sentences"]
        self.db_meta: list[dict] = data["meta"]

        with open(f"{VOL}/sources.json", "r", encoding="utf-8") as f:
            self.sources: dict[str, dict] = json.load(f)

        with open(f"{VOL}/meta.json", "r", encoding="utf-8") as f:
            self.index_meta = json.load(f)

        self.faiss_index = faiss.read_index(f"{VOL}/faiss.index")

        print("Завантаження bi-encoder + cross-encoder на GPU...")
        self.retriever = SentenceTransformer(
            f"{MODELS}/biencoder_ft", device="cuda"
        )
        self.reranker = CrossEncoder(
            "BAAI/bge-reranker-v2-m3", device="cuda", max_length=512
        )

        print(
            f"Готовий. Корпус: {len(self.db_sentences)} речень, "
            f"{len(self.sources)} документів."
        )

    @modal.method()
    def check(
        self,
        text: str,
        top_k: int = 20,
        threshold: float = 0.7,
        mode: str = "accurate",
    ) -> dict[str, Any]:

        import numpy as np

        check_sentences = split_sentences(text)
        if not check_sentences:
            return self._empty_result(0)

        q_embs = self.retriever.encode(
            check_sentences,
            batch_size=64,
            convert_to_numpy=True,
            normalize_embeddings=True,
        ).astype("float32")

        sims, idxs = self.faiss_index.search(q_embs, top_k)

        if mode == "fast":
            matches = []
            for qi, query in enumerate(check_sentences):
                best_idx = int(idxs[qi, 0])
                best_score = float(sims[qi, 0])
                if best_idx >= 0 and best_score >= threshold:
                    matches.append(
                        self._make_match(query, qi, best_idx, best_score)
                    )
            return self._build_result(check_sentences, matches)

        pairs: list[tuple[str, str]] = []
        pair_origin: list[tuple[int, int]] = []  # (query_idx, db_idx)
        for qi in range(len(check_sentences)):
            for ki in range(top_k):
                db_idx = int(idxs[qi, ki])
                if db_idx < 0:
                    continue
                pairs.append((check_sentences[qi], self.db_sentences[db_idx]))
                pair_origin.append((qi, db_idx))

        if not pairs:
            return self._empty_result(len(check_sentences))

        raw = self.reranker.predict(
            pairs,
            batch_size=32,
            show_progress_bar=False,
            convert_to_numpy=True,
        )
        scores = 1.0 / (1.0 + np.exp(-raw))

        best_per_query: dict[int, tuple[int, float]] = {}
        for (qi, db_idx), score in zip(pair_origin, scores):
            cur = best_per_query.get(qi)
            if cur is None or score > cur[1]:
                best_per_query[qi] = (db_idx, float(score))

        matches = []
        for qi, (db_idx, score) in best_per_query.items():
            if score >= threshold:
                matches.append(
                    self._make_match(check_sentences[qi], qi, db_idx, score)
                )

        return self._build_result(check_sentences, matches)

    def _make_match(
        self, query: str, qi: int, db_idx: int, score: float
    ) -> dict[str, Any]:
        meta = self.db_meta[db_idx]
        source = self.sources.get(meta["source_id"], {})
        if score >= 0.80:
            confidence = "high"
        elif score >= 0.70:
            confidence = "medium"
        else:
            confidence = "low"
        return {
            "suspicious": query,
            "suspicious_position": qi,
            "original": self.db_sentences[db_idx],
            "source_id": meta["source_id"],
            "source_title": source.get("title", meta["source_id"]),
            "score": round(score, 4),
            "confidence": confidence,
        }

    def _build_result(
        self, check_sentences: list[str], matches: list[dict]
    ) -> dict[str, Any]:
        by_source: dict[str, dict] = {}
        for m in matches:
            sid = m["source_id"]
            if sid not in by_source:
                by_source[sid] = {
                    "source_id": sid,
                    "source_title": m["source_title"],
                    "match_count": 0,
                    "max_score": 0.0,
                    "_scores": [],
                }
            entry = by_source[sid]
            entry["match_count"] += 1
            entry["max_score"] = max(entry["max_score"], m["score"])
            entry["_scores"].append(m["score"])

        sources_summary = []
        for entry in by_source.values():
            scores_list = entry.pop("_scores")
            entry["avg_score"] = round(sum(scores_list) / len(scores_list), 4)
            entry["max_score"] = round(entry["max_score"], 4)
            sources_summary.append(entry)
        sources_summary.sort(key=lambda x: x["match_count"], reverse=True)

        n_total = len(check_sentences)
        n_match = len(matches)
        return {
            "percentage": round(100 * n_match / n_total, 2) if n_total else 0.0,
            "total_sentences": n_total,
            "matched_sentences": n_match,
            "matches": sorted(matches, key=lambda m: m["suspicious_position"]),
            "sources_summary": sources_summary,
            "sentences": check_sentences,
        }

    def _empty_result(self, n: int) -> dict[str, Any]:
        return {
            "percentage": 0.0,
            "total_sentences": n,
            "matched_sentences": 0,
            "matches": [],
            "sources_summary": [],
            "sentences": [],
        }

@app.function(image=image, min_containers=0)
@modal.fastapi_endpoint(method="POST", docs=True)
def check_endpoint(payload: dict) -> dict[str, Any]:

    detector = PlagDetector()
    return detector.check.remote(
        text=payload["text"],
        top_k=int(payload.get("top_k", 20)),
        threshold=float(payload.get("threshold", 0.7)),
        mode=str(payload.get("mode", "accurate")),
    )

@app.local_entrypoint()
def main(
    file: str,
    top_k: int = 20,
    threshold: float = 0.7,
    mode: str = "accurate",
) -> None:
    text = Path(file).read_text(encoding="utf-8")
    detector = PlagDetector()
    result = detector.check.remote(
        text=text, top_k=top_k, threshold=threshold, mode=mode
    )
    print(f"\n{'=' * 60}")
    print(
        f"Запозичено: {result['percentage']}% "
        f"({result['matched_sentences']} з {result['total_sentences']} речень)"
    )
    print("=" * 60)
    for i, m in enumerate(result["matches"], 1):
        print(f"\n#{i} (score={m['score']}, {m['confidence']})")
        print(f"   Джерело:  {m['source_title']}")
        print(f"   Запит:    «{m['suspicious'][:140]}»")
        print(f"   Оригінал: «{m['original'][:140]}»")