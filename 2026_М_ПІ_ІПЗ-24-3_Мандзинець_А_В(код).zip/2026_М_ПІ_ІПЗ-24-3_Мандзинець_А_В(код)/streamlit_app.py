from __future__ import annotations

import os
from typing import Any

import requests
import streamlit as st

from report import render_report


st.set_page_config(
    page_title="Plagiarism Detector",
    page_icon="",
    layout="wide",
    initial_sidebar_state="expanded",
)

DEFAULT_SETTINGS: dict[str, Any] = {
    "threshold": 0.70,
    "top_k": 20,
    "mode": "accurate",
}

if "result" not in st.session_state:
    st.session_state.result = None
if "settings" not in st.session_state:
    st.session_state.settings = DEFAULT_SETTINGS.copy()
if "endpoint_url" not in st.session_state:
    st.session_state.endpoint_url = os.getenv("MODAL_ENDPOINT_URL", "")
if "last_input" not in st.session_state:
    st.session_state.last_input = {"name": None, "size": 0}

with st.sidebar:
    st.markdown("## Plagiarism Detector")
    page = st.radio(
        "Сторінка",
        ["Завантаження", "Звіт", "Налаштування"],
        label_visibility="collapsed",
    )
    st.markdown("---")
    if st.session_state.endpoint_url:
        st.caption(f"🟢 Підключено до Modal")
    else:
        st.caption("🔴 URL не задано — див. Налаштування")


if page == "Завантаження":
    st.title("Перевірка документа")
    st.caption(
        "Завантажте .txt файл або вставте текст"
    )

    if not st.session_state.endpoint_url:
        st.warning(
            "URL Modal-сервісу не задано. Перейдіть у «Налаштування» "
            "та вкажіть endpoint."
        )

    col_left, col_right = st.columns([3, 2])

    with col_left:
        uploaded = st.file_uploader(
            "Файл документа", type=["txt"], label_visibility="visible"
        )
        text_input = st.text_area(
            "Або вставте текст", height=240, placeholder="Вставте текст для перевірки..."
        )

    with col_right:
        st.markdown("##### Поточні параметри")
        s = st.session_state.settings
        st.code(
            f"mode      = {s['mode']}\n"
            f"threshold = {s['threshold']}\n"
            f"top_k     = {s['top_k']}",
            language="ini",
        )
        st.caption("Змінити можна на сторінці «Налаштування».")

    text: str | None = None
    if uploaded is not None:
        try:
            text = uploaded.read().decode("utf-8", errors="replace")
            st.info(
                f"Завантажено: **{uploaded.name}** "
                f"({len(text):,} символів)".replace(",", " ")
            )
            st.session_state.last_input = {"name": uploaded.name, "size": len(text)}
        except Exception as e:
            st.error(f"Не вдалося прочитати файл: {e}")
    elif text_input.strip():
        text = text_input
        st.session_state.last_input = {"name": "(вставлений текст)", "size": len(text)}

    can_check = (
        text is not None
        and bool(st.session_state.endpoint_url)
    )

    if st.button("Запустити перевірку", type="primary", disabled=not can_check):
        with st.spinner("Виконується перевірка… "):
            try:
                resp = requests.post(
                    st.session_state.endpoint_url,
                    json={"text": text, **st.session_state.settings},
                    timeout=600,
                )
                resp.raise_for_status()
                st.session_state.result = resp.json()
                st.success(
                    f"Готово. Запозичено: "
                    f"{st.session_state.result['percentage']}%. "
                    f"Перейдіть на «Звіт»."
                )
            except requests.HTTPError as e:
                st.error(f"HTTP-помилка {resp.status_code}: {resp.text[:500]}")
            except requests.Timeout:
                st.error(
                    "Тайм-аут (>10 хв). Скоротіть текст або збільште timeout "
                    "у налаштуваннях Modal."
                )
            except requests.ConnectionError as e:
                st.error(f"Помилка з'єднання: {e}")
            except Exception as e:
                st.error(f"Несподівана помилка: {e}")

elif page == "Звіт":
    st.title("Звіт")
    result = st.session_state.result

    if not result:
        st.info(
            "Ще немає результатів. Перейдіть у «Завантаження» та запустіть перевірку."
        )
    else:
        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Запозичено", f"{result['percentage']}%")
        m2.metric("Збігів речень", result["matched_sentences"])
        m3.metric("Всього речень", result["total_sentences"])
        m4.metric("Унікальних джерел", len(result.get("sources_summary", [])))

        st.markdown("---")

        html = render_report(result)
        st.components.v1.html(html, height=900, scrolling=True)

        st.markdown("---")

        c1, c2 = st.columns(2)
        with c1:
            st.download_button(
                "Завантажити звіт (HTML)",
                data=html,
                file_name="plagiarism_report.html",
                mime="text/html",
                use_container_width=True,
            )
        with c2:
            import json as _json

            st.download_button(
                "Завантажити сирий результат (JSON)",
                data=_json.dumps(result, ensure_ascii=False, indent=2),
                file_name="plagiarism_result.json",
                mime="application/json",
                use_container_width=True,
            )

elif page == "Налаштування":
    st.title("Налаштування")

    # ---- Підключення ----
    st.subheader("Підключення")
    new_url = st.text_input(
        "URL Modal-сервісу (POST endpoint)",
        value=st.session_state.endpoint_url,
        placeholder="https://<workspace>--plag-detector-check-endpoint.modal.run",
        help="Отримуєте після `modal deploy modal_app.py`",
    )
    if new_url != st.session_state.endpoint_url:
        st.session_state.endpoint_url = new_url
        st.success("URL оновлено.")

    if st.session_state.endpoint_url and st.button("Перевірити доступність"):
        try:
            with st.spinner("Виклик з мінімальним текстом-пінгом..."):
                resp = requests.post(
                    st.session_state.endpoint_url,
                    json={
                        "text": "Це тестове речення для перевірки доступності сервісу.",
                        "top_k": 1,
                        "threshold": 0.99,
                        "mode": "fast",
                    },
                    timeout=120,
                )
                resp.raise_for_status()
                st.success(
                    f"Сервіс доступний. Час: "
                    f"{resp.elapsed.total_seconds():.1f} с"
                )
        except Exception as e:
            st.error(f"Сервіс недоступний: {e}")

    st.markdown("---")

    st.subheader("Параметри детекції")
    s = st.session_state.settings

    s["mode"] = st.radio(
        "Режим",
        ["accurate", "fast"],
        index=0 if s["mode"] == "accurate" else 1,
        format_func=lambda m: {
            "accurate": "Точний — bi-encoder + cross-encoder (повільніше, точніше)",
            "fast": "Швидкий — лише bi-encoder (без реранкера)",
        }[m],
    )

    s["threshold"] = st.slider(
        "Поріг прийняття рішення",
        0.30, 0.95, s["threshold"], 0.05,
        help=(
            "Для accurate: значення сигмоїди логіта крос-енкодера. "
            "Для fast: cosine similarity bi-encoder. "
            "Нижче поріг — більше знаходить, але і більше хибних спрацьовувань."
        ),
    )

    s["top_k"] = st.slider(
        "Top-k кандидатів від retriever",
        5, 50, s["top_k"], 5,
        help="Скільки кандидатів FAISS передаються реранкеру для кожного речення.",
    )

    if st.button("Скинути до значень за замовчуванням"):
        st.session_state.settings = DEFAULT_SETTINGS.copy()
        st.rerun()
