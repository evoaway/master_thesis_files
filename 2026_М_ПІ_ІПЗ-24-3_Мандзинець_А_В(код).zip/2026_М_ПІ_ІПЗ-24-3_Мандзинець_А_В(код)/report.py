from __future__ import annotations

import html as _html
from typing import Any


CSS = """
:root {
  --bg: #fafaf7;
  --paper: #ffffff;
  --ink: #1a1a1a;
  --muted: #6b6b6b;
  --rule: #e5e5e0;
  --high-bg: #fde2e2;
  --high-line: #c2410c;
  --med-bg: #fef3c7;
  --med-line: #b45309;
  --low-bg: #e5e7eb;
  --low-line: #6b7280;
  --accent: #1a1a1a;
}

* { box-sizing: border-box; }

body {
  font-family: "Iowan Old Style", "Charter", "Source Serif Pro", Georgia, serif;
  background: var(--bg);
  color: var(--ink);
  line-height: 1.65;
  margin: 0;
  padding: 2.5rem 1.5rem;
}

.container {
  max-width: 980px;
  margin: 0 auto;
}

header {
  border-bottom: 2px solid var(--ink);
  padding-bottom: 1.25rem;
  margin-bottom: 2rem;
}

header .label {
  font-family: "JetBrains Mono", "SF Mono", Menlo, monospace;
  font-size: 0.7rem;
  letter-spacing: 0.18em;
  text-transform: uppercase;
  color: var(--muted);
  margin-bottom: 0.5rem;
}

header h1 {
  font-size: 2.4rem;
  font-weight: 600;
  letter-spacing: -0.02em;
  margin: 0;
}

.summary {
  display: grid;
  grid-template-columns: auto 1fr auto;
  gap: 2.5rem;
  align-items: baseline;
  background: var(--paper);
  border: 1px solid var(--rule);
  padding: 1.75rem 2rem;
  margin-bottom: 2rem;
}

.summary .pct {
  font-size: 4rem;
  font-weight: 700;
  letter-spacing: -0.04em;
  line-height: 1;
}

.summary .pct .sym {
  font-size: 0.45em;
  font-weight: 400;
  color: var(--muted);
  margin-left: 0.1em;
}

.summary .meta {
  font-family: "JetBrains Mono", "SF Mono", Menlo, monospace;
  font-size: 0.85rem;
  color: var(--muted);
  line-height: 1.8;
}

.summary .meta b { color: var(--ink); }

.summary .verdict {
  text-align: right;
  font-family: "JetBrains Mono", "SF Mono", Menlo, monospace;
  font-size: 0.75rem;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  padding: 0.35rem 0.7rem;
  border: 1px solid currentColor;
}

.verdict.clean { color: #065f46; }
.verdict.minor { color: #b45309; }
.verdict.major { color: #c2410c; }

.legend {
  font-family: "JetBrains Mono", "SF Mono", Menlo, monospace;
  font-size: 0.75rem;
  color: var(--muted);
  margin-bottom: 1rem;
  display: flex;
  gap: 1.25rem;
  flex-wrap: wrap;
}

.legend span.swatch { padding: 0.1rem 0.5rem; }

.section-title {
  font-family: "JetBrains Mono", "SF Mono", Menlo, monospace;
  font-size: 0.75rem;
  letter-spacing: 0.18em;
  text-transform: uppercase;
  color: var(--muted);
  margin: 2rem 0 0.75rem 0;
  padding-bottom: 0.5rem;
  border-bottom: 1px solid var(--rule);
}

.text {
  background: var(--paper);
  border: 1px solid var(--rule);
  padding: 2rem 2.25rem;
  font-size: 1.05rem;
  text-align: justify;
  hyphens: auto;
}

.match {
  padding: 0.05rem 0.15rem;
  border-radius: 2px;
  cursor: help;
  transition: background 0.15s ease;
}
.match.high { background: var(--high-bg); border-bottom: 2px solid var(--high-line); }
.match.medium { background: var(--med-bg); border-bottom: 2px solid var(--med-line); }
.match.low { background: var(--low-bg); border-bottom: 2px solid var(--low-line); }
.match:hover { filter: brightness(0.96); }

.sources {
  margin-top: 1rem;
}

.source-row {
  display: grid;
  grid-template-columns: 1fr auto auto;
  gap: 1.5rem;
  padding: 0.75rem 0;
  border-bottom: 1px solid var(--rule);
  align-items: baseline;
  font-size: 0.95rem;
}

.source-row:last-child { border-bottom: none; }

.source-title {
  font-weight: 500;
}

.source-stat {
  font-family: "JetBrains Mono", "SF Mono", Menlo, monospace;
  font-size: 0.8rem;
  color: var(--muted);
  white-space: nowrap;
}

.matches-list {
  margin-top: 0.75rem;
}

.match-card {
  background: var(--paper);
  border: 1px solid var(--rule);
  border-left: 3px solid var(--rule);
  padding: 1rem 1.25rem;
  margin-bottom: 0.75rem;
  font-size: 0.95rem;
}

.match-card.high { border-left-color: var(--high-line); }
.match-card.medium { border-left-color: var(--med-line); }
.match-card.low { border-left-color: var(--low-line); }

.match-card .head {
  font-family: "JetBrains Mono", "SF Mono", Menlo, monospace;
  font-size: 0.75rem;
  color: var(--muted);
  margin-bottom: 0.5rem;
  display: flex;
  justify-content: space-between;
  gap: 1rem;
}

.match-card .pair {
  display: grid;
  grid-template-columns: auto 1fr;
  gap: 0.5rem 1rem;
  font-size: 0.93rem;
}

.match-card .pair .lbl {
  font-family: "JetBrains Mono", "SF Mono", Menlo, monospace;
  font-size: 0.7rem;
  letter-spacing: 0.1em;
  text-transform: uppercase;
  color: var(--muted);
  padding-top: 0.15em;
}

.empty {
  text-align: center;
  padding: 3rem 1rem;
  color: var(--muted);
  font-style: italic;
}
"""


def _verdict(pct: float) -> tuple[str, str]:
    if pct < 15:
        return "clean", "Унікальний"
    if pct < 30:
        return "minor", "Невеликі запозичення"
    return "major", "Високий рівень запозичень"


def _make_tooltip(m: dict) -> str:
    return (
        f"score={m['score']:.3f} | "
        f"джерело: {m['source_title']} | "
        f"оригінал: «{m['original'][:200]}»"
    )


def render_report(result: dict[str, Any]) -> str:
    sentences: list[str] = result.get("sentences", [])
    matches: list[dict] = result.get("matches", [])
    sources: list[dict] = result.get("sources_summary", [])

    pct = result.get("percentage", 0.0)
    verdict_cls, verdict_text = _verdict(pct)

    pos_to_match = {m["suspicious_position"]: m for m in matches}

    if sentences:
        chunks = []
        for i, sent in enumerate(sentences):
            if i in pos_to_match:
                m = pos_to_match[i]
                tooltip = _html.escape(_make_tooltip(m))
                chunks.append(
                    f'<span class="match {m["confidence"]}" title="{tooltip}">'
                    f"{_html.escape(sent)}</span>"
                )
            else:
                chunks.append(_html.escape(sent))
        text_block = "<div class=\"text\">" + " ".join(chunks) + "</div>"
    else:
        text_block = '<div class="empty">Документ не містить тексту для аналізу.</div>'

    if sources:
        rows = []
        for s in sources:
            rows.append(
                f'<div class="source-row">'
                f'<span class="source-title">{_html.escape(s["source_title"])}</span>'
                f'<span class="source-stat">{s["match_count"]} збіг(ів)</span>'
                f'<span class="source-stat">max {s["max_score"]:.2f} | avg {s["avg_score"]:.2f}</span>'
                f"</div>"
            )
        sources_block = (
            '<div class="section-title">Виявлені джерела</div>'
            '<div class="sources">' + "".join(rows) + "</div>"
        )
    else:
        sources_block = ""

    if matches:
        cards = []
        for i, m in enumerate(matches, 1):
            cards.append(
                f'<div class="match-card {m["confidence"]}">'
                f'<div class="head">'
                f"<span>#{i:03d} · речення {m['suspicious_position'] + 1}</span>"
                f'<span>score={m["score"]:.3f} · {m["confidence"]}</span>'
                f"</div>"
                f'<div class="pair">'
                f'<div class="lbl">Запит</div><div>{_html.escape(m["suspicious"])}</div>'
                f'<div class="lbl">Оригінал</div><div>{_html.escape(m["original"])}</div>'
                f'<div class="lbl">Джерело</div><div>{_html.escape(m["source_title"])}</div>'
                f"</div></div>"
            )
        matches_block = (
            '<div class="section-title">Перелік збігів</div>'
            '<div class="matches-list">' + "".join(cards) + "</div>"
        )
    else:
        matches_block = ""

    return f"""<!doctype html>
<html lang="uk">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Звіт про перевірку плагіату</title>
  <style>{CSS}</style>
</head>
<body>
  <div class="container">
    <header>
      <h1>Звіт про перевірку</h1>
    </header>

    <div class="summary">
      <div class="pct">{pct:.1f}<span class="sym">%</span></div>
      <div class="meta">
        <div><b>{result.get('matched_sentences', 0)}</b> з <b>{result.get('total_sentences', 0)}</b> речень мають запозичення</div>
        <div>Виявлено унікальних джерел: <b>{len(sources)}</b></div>
      </div>
      <div class="verdict {verdict_cls}">{verdict_text}</div>
    </div>

    <div class="legend">
      <span><span class="swatch match high">високий</span> ≥ 0.80</span>
      <span><span class="swatch match medium">середній</span> 0.70 – 0.80</span>
      <span><span class="swatch match low">низький</span> &lt; 0.70</span>
    </div>

    <div class="section-title">Текст документа</div>
    {text_block}

    {sources_block}

    {matches_block}
  </div>
</body>
</html>"""
